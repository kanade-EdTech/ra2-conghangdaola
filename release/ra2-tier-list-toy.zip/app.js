(function (global) {
  'use strict';
  var app = global.RA2;
  var core = app.core;
  var storage = app.createStorage(function () { return global.localStorage; });
  var loaded = storage.load();
  var state = loaded.state;
  var history = core.createHistory();
  var dialog = app.createDialog();
  var boardElement = document.getElementById('tier-board');
  var poolElement = document.getElementById('country-pool');
  var titleInput = document.getElementById('board-title');
  var exportButton = document.getElementById('export-button');
  var undoButton = document.getElementById('undo-button');
  var titleBefore = null;
  var composing = false;
  var generating = false;
  var saveTimer = null;
  var toastTimer = null;

  function element(tag, className, text) {
    var node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = text;
    return node;
  }
  function button(text, className, handler) {
    var node = element('button', className, text);
    node.type = 'button';
    node.addEventListener('click', handler);
    return node;
  }
  function board() { return state.boards[state.activeVersion]; }
  function toast(message) {
    var node = document.getElementById('toast');
    clearTimeout(toastTimer);
    node.textContent = message; node.hidden = false;
    toastTimer = setTimeout(function () { node.hidden = true; }, 3800);
  }
  function saveStatus(status) {
    var node = document.getElementById('save-status');
    var messages = {
      new: '排名会自动保存到本机',
      restored: '已恢复上次排名 · 仅保存在本机',
      repaired: '已修复草稿中的重复或缺失项目',
      saved: '草稿已保存到本机',
      pending: '正在保存草稿…',
      failed: '草稿未能保存，当前排名仅保留在本次页面',
      protected: '草稿不可读取，当前仅保留本次排名；原草稿不会覆盖'
    };
    node.textContent = messages[status] || messages.new;
    node.classList.toggle('warning', status === 'failed' || status === 'protected');
  }
  function flush() {
    clearTimeout(saveTimer);
    saveTimer = null;
    saveStatus(storage.save(state));
  }
  function scheduleSave() {
    clearTimeout(saveTimer);
    saveStatus('pending');
    saveTimer = setTimeout(flush, 220);
  }
  function image(country) {
    var img = element('img', 'flag-image');
    img.src = country.iconPath; img.alt = ''; img.width = 58; img.height = 28;
    img.draggable = false;
    img.addEventListener('error', function () {
      var fallback = element('span', 'flag-fallback', country.name.charAt(0));
      if (img.parentNode) img.parentNode.replaceChild(fallback, img);
    });
    return img;
  }
  function card(id) {
    var country = app.countryById[id];
    var outer = element('div', 'country-card');
    outer.setAttribute('data-country', id);
    var main = element('button', 'card-main');
    main.type = 'button'; main.setAttribute('aria-label', '为' + country.name + '定档');
    main.appendChild(image(country));
    main.appendChild(element('span', 'country-name', country.name));
    outer.appendChild(main);
    outer.appendChild(element('i', 'faction-dot ' + country.faction));
    var handle = element('button', 'drag-handle');
    handle.type = 'button'; handle.setAttribute('aria-label', '拖动' + country.name + '，也可点选定档');
    handle.innerHTML = '<svg viewBox="0 0 12 20" aria-hidden="true"><g fill="currentColor"><circle cx="3" cy="4" r="1.3"/><circle cx="9" cy="4" r="1.3"/><circle cx="3" cy="10" r="1.3"/><circle cx="9" cy="10" r="1.3"/><circle cx="3" cy="16" r="1.3"/><circle cx="9" cy="16" r="1.3"/></g></svg>';
    outer.appendChild(handle);
    return outer;
  }
  function populate(container, ids, emptyText) {
    if (!ids.length) container.appendChild(element('span', 'empty-hint', emptyText));
    ids.forEach(function (id) { container.appendChild(card(id)); });
  }
  function render() {
    var current = board();
    boardElement.textContent = '';
    app.tiers.forEach(function (tier) {
      var row = element('div', 'tier-row');
      var label = element('div', 'tier-label');
      label.style.backgroundColor = tier.color;
      label.appendChild(element('strong', '', tier.name));
      label.appendChild(element('small', '', tier.hint));
      var list = element('div', 'card-list');
      list.setAttribute('data-dropzone', tier.id);
      list.setAttribute('role', 'group'); list.setAttribute('aria-label', tier.name + '档');
      populate(list, current.tiers[tier.id], '点选国家，或拖到这一档');
      row.appendChild(label); row.appendChild(list); boardElement.appendChild(row);
    });
    poolElement.textContent = '';
    populate(poolElement, current.unranked, '全部定档完毕！也可以把卡片移回来。');
    var total = core.ids(state.activeVersion).length;
    var placed = total - current.unranked.length;
    document.getElementById('progress-label').textContent = '已排 ' + placed + ' / ' + total;
    document.getElementById('progress-bar').style.width = (placed / total * 100) + '%';
    document.getElementById('pool-count').textContent = current.unranked.length;
    if (document.activeElement !== titleInput) titleInput.value = current.title;
    document.getElementById('title-count').textContent = Array.from(titleInput.value).length + '/30';
    document.querySelectorAll('[data-version]').forEach(function (node) {
      node.setAttribute('aria-pressed', String(node.getAttribute('data-version') === state.activeVersion));
    });
    undoButton.disabled = !history.count(state.activeVersion);
  }
  function commit(next) {
    if (!core.validate(next, state.activeVersion)) { toast('排名数据校验失败，请重试'); return false; }
    if (JSON.stringify(next) === JSON.stringify(board())) return false;
    history.push(state.activeVersion, board());
    state.boards[state.activeVersion] = next;
    render(); scheduleSave();
    return true;
  }
  function move(id, target, index) {
    try {
      var changed = commit(core.move(board(), state.activeVersion, id, target, index));
      if (changed) {
        var tier = app.tiers.filter(function (value) { return value.id === target; })[0];
        toast(app.countryById[id].name + '已移至' + (tier ? tier.name + '档' : '待排名'));
      }
    } catch (error) { toast(error.message || '移动失败，请重试'); }
  }
  function finishTitle() {
    if (titleBefore === null) return;
    var current = board();
    if (current.title !== titleBefore) {
      var previous = core.clone(current);
      previous.title = titleBefore;
      history.push(state.activeVersion, previous);
      undoButton.disabled = false;
    }
    titleBefore = null;
  }
  function updateTitle() {
    if (composing) return;
    var value = core.limitTitle(titleInput.value);
    titleInput.value = value;
    board().title = value;
    document.getElementById('title-count').textContent = Array.from(value).length + '/30';
    scheduleSave();
  }
  titleInput.addEventListener('focus', function () { titleBefore = board().title; });
  titleInput.addEventListener('input', updateTitle);
  titleInput.addEventListener('compositionstart', function () { composing = true; });
  titleInput.addEventListener('compositionend', function () { composing = false; updateTitle(); });
  titleInput.addEventListener('blur', finishTitle);

  function openCountry(id) {
    var country = app.countryById[id];
    var position = core.locate(board(), id);
    var wrapper = element('div');
    var detail = element('div', 'country-detail');
    detail.appendChild(image(country));
    var text = element('div');
    var heading = element('h2', '', country.name);
    heading.id = 'modal-title';
    text.appendChild(heading);
    text.appendChild(element('p', '', app.factions[country.faction] + ' · ' + country.signature));
    detail.appendChild(text); wrapper.appendChild(detail);
    wrapper.appendChild(element('p', 'modal-description', '给它选一档，排出你的看法。'));
    var choices = element('div', 'choice-grid');
    app.tiers.forEach(function (tier) {
      var choice = button(tier.name, 'tier-choice', function () {
        if (position.location !== tier.id) move(id, tier.id);
        dialog.hide(); focusCard(id);
      });
      choice.style.backgroundColor = tier.color;
      choice.setAttribute('aria-label', '移至' + tier.name + '档');
      choice.setAttribute('aria-pressed', String(position.location === tier.id));
      choices.appendChild(choice);
    });
    wrapper.appendChild(choices);
    var actions = element('div', 'modal-actions');
    var previous = button('← 前移', 'secondary-button', function () {
      move(id, position.location, position.index - 1); dialog.hide(); focusCard(id);
    });
    previous.disabled = position.index === 0;
    var next = button('后移 →', 'secondary-button', function () {
      move(id, position.location, position.index + 1); dialog.hide(); focusCard(id);
    });
    next.disabled = position.index === core.list(board(), position.location).length - 1;
    var unrank = button('移回待排名', 'secondary-button', function () {
      move(id, 'unranked'); dialog.hide(); focusCard(id);
    });
    unrank.disabled = position.location === 'unranked';
    actions.appendChild(previous); actions.appendChild(next); actions.appendChild(unrank);
    wrapper.appendChild(actions);
    wrapper.appendChild(element('p', 'modal-note', '同档卡片从左到右排列；排名依据由你决定。'));
    dialog.show(wrapper);
  }
  function focusCard(id) {
    var node = document.querySelector('[data-country="' + id + '"] .card-main');
    if (node) node.focus();
  }
  document.querySelector('.workspace').addEventListener('click', function (event) {
    var target = event.target.closest('.card-main, .drag-handle');
    if (target && !generating) openCountry(target.closest('.country-card').getAttribute('data-country'));
  });
  document.querySelectorAll('[data-version]').forEach(function (node) {
    node.addEventListener('click', function () {
      finishTitle(); flush();
      state.activeVersion = node.getAttribute('data-version');
      render(); flush();
    });
  });
  function undo() {
    finishTitle();
    var previous = history.pop(state.activeVersion);
    if (!previous) return;
    state.boards[state.activeVersion] = previous;
    render(); scheduleSave(); toast('已撤销上一步');
  }
  undoButton.addEventListener('click', undo);
  document.addEventListener('keydown', function (event) {
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'z' &&
        event.target.tagName !== 'INPUT' && !dialog.isOpen()) {
      event.preventDefault(); undo();
    }
  });
  document.getElementById('reset-button').addEventListener('click', function () {
    var wrapper = element('div');
    var heading = element('h2', '', '重新排名？'); heading.id = 'modal-title';
    wrapper.appendChild(heading);
    wrapper.appendChild(element('p', 'modal-description', '将' + app.versions[state.activeVersion] + '的卡片全部移回待排名。榜单名称会保留，也可以撤销这一步。'));
    var actions = element('div', 'modal-actions');
    actions.appendChild(button('保留排名', 'secondary-button', dialog.hide));
    actions.appendChild(button('确认重置', 'primary-button', function () {
      commit(core.reset(board(), state.activeVersion)); dialog.hide(); toast('已重新开始，仍可撤销');
    }));
    wrapper.appendChild(actions); dialog.show(wrapper);
  });

  async function exportPoster(width) {
    if (generating) return;
    finishTitle(); flush();
    generating = true; exportButton.disabled = true; exportButton.textContent = '正在生成…';
    var snapshot = core.clone(board());
    var version = state.activeVersion;
    try {
      var poster = await app.createPoster(snapshot, version, width);
      var wrapper = element('div');
      var heading = element('h2', '', '你的排名，已就位。'); heading.id = 'modal-title';
      wrapper.appendChild(heading);
      wrapper.appendChild(element('p', 'modal-description', app.versions[version] + ' · ' + poster.width + ' × ' + poster.height));
      var preview = element('img', 'poster-preview'); preview.src = poster.data;
      preview.alt = (snapshot.title || '我的排名') + '结果图，' + app.versions[version];
      wrapper.appendChild(preview);
      var note = element('p', 'modal-note', app.platform.hint);
      var actions = element('div', 'poster-actions');
      var save = button('保存图片', 'primary-button', async function () {
        save.disabled = true; save.textContent = '正在保存…';
        try {
          var message = await app.platform.saveImage(poster.data, 'ra2-tier-list-' + version + '.png');
          note.textContent = message; toast(message);
        } catch (error) {
          var message = error.errMsg || error.message || '保存未完成，请检查相册权限后重试';
          note.textContent = message; toast(message);
        } finally { save.disabled = false; save.textContent = '保存图片'; }
      });
      var light = button(width === 720 ? '已是轻量画质' : '轻量画质', 'secondary-button', function () {
        dialog.hide(); exportPoster(720);
      });
      light.disabled = width === 720;
      actions.appendChild(save); actions.appendChild(light);
      wrapper.appendChild(actions); wrapper.appendChild(note);
      dialog.show(wrapper, { poster: true, cleanup: function () { preview.removeAttribute('src'); poster.data = ''; } });
    } catch (error) {
      var wrapper = element('div');
      var heading = element('h2', '', '图片暂未生成'); heading.id = 'modal-title';
      wrapper.appendChild(heading);
      wrapper.appendChild(element('p', 'modal-description', error.message || '请稍后重试，当前排名会保留。'));
      wrapper.appendChild(button('用轻量画质重试', 'primary-button', function () { dialog.hide(); exportPoster(720); }));
      dialog.show(wrapper);
    } finally {
      generating = false; exportButton.disabled = false;
      exportButton.innerHTML = '生成结果图 <span aria-hidden="true">↗</span>';
    }
  }
  exportButton.addEventListener('click', function () { exportPoster(1080); });
  app.installDrag(document.querySelector('.workspace'), {
    disabled: function () { return dialog.isOpen() || generating; },
    move: move,
    tap: openCountry
  });
  document.addEventListener('visibilitychange', function () { if (document.hidden) flush(); });
  global.addEventListener('pagehide', flush);
  if (global.visualViewport) {
    global.visualViewport.addEventListener('resize', function () {
      document.getElementById('modal').style.maxHeight = Math.floor(global.visualViewport.height * .85) + 'px';
    });
  }
  render(); saveStatus(loaded.status);
})(window);
