(function (global) {
  'use strict';
  global.RA2.installDrag = function (root, options) {
    var gesture = null;
    var ghost = null;
    var target = null;
    var frame = null;
    var suppressUntil = 0;
    var suppressCardId = null;
    var mainTap = null;
    var pendingTouchClick = false;
    function touchTap(id) {
      suppressUntil = Date.now() + 450;
      suppressCardId = id;
      pendingTouchClick = true;
      options.tap(id);
    }
    function clearTarget() {
      root.querySelectorAll('.drop-active, .drop-before, .drop-after').forEach(function (element) {
        element.classList.remove('drop-active', 'drop-before', 'drop-after');
      });
      target = null;
    }
    function updateTarget() {
      clearTarget();
      if (!gesture || !gesture.started) return;
      var hit = document.elementFromPoint(gesture.x, gesture.y);
      var zone = hit && hit.closest('[data-dropzone]');
      if (!zone || !root.contains(zone)) return;
      zone.classList.add('drop-active');
      var cards = Array.from(zone.querySelectorAll('.country-card')).filter(function (card) {
        return card !== gesture.card;
      });
      var index = cards.length;
      var before = null;
      for (var i = 0; i < cards.length; i++) {
        var rect = cards[i].getBoundingClientRect();
        if (gesture.y < rect.top || (gesture.y <= rect.bottom && gesture.x < rect.left + rect.width / 2)) {
          index = i; before = cards[i]; break;
        }
      }
      if (before) before.classList.add('drop-before');
      else if (cards.length) cards[cards.length - 1].classList.add('drop-after');
      target = { location: zone.getAttribute('data-dropzone'), index: index };
    }
    function scrollTick() {
      if (!gesture || !gesture.started) return;
      var edge = 72;
      var speed = gesture.y < edge ? -Math.min(12, (edge - gesture.y) / 5) :
        gesture.y > global.innerHeight - edge ? Math.min(12, (gesture.y - global.innerHeight + edge) / 5) : 0;
      if (speed) { global.scrollBy(0, speed); updateTarget(); }
      frame = global.requestAnimationFrame(scrollTick);
    }
    function down(event, point, pointerId) {
      var handle = event.target.closest('.drag-handle');
      if (!handle || options.disabled()) return;
      if (event.button !== undefined && event.button !== 0) return;
      var card = handle.closest('.country-card');
      gesture = {
        id: card.getAttribute('data-country'), card: card, pointerId: pointerId,
        touch: event.pointerType === 'touch' || pointerId === 'touch',
        startX: point.clientX, startY: point.clientY, x: point.clientX, y: point.clientY, started: false
      };
    }
    function move(event, point, pointerId) {
      if (!gesture || gesture.pointerId !== pointerId) return;
      gesture.x = point.clientX; gesture.y = point.clientY;
      if (!gesture.started && Math.abs(gesture.x - gesture.startX) + Math.abs(gesture.y - gesture.startY) > 7) {
        gesture.started = true;
        gesture.card.classList.add('is-dragging');
        ghost = gesture.card.cloneNode(true);
        ghost.classList.remove('is-dragging');
        ghost.classList.add('drag-ghost');
        ghost.setAttribute('aria-hidden', 'true');
        ghost.querySelectorAll('button').forEach(function (button) { button.tabIndex = -1; });
        document.body.appendChild(ghost);
        scrollTick();
      }
      if (!gesture.started) return;
      if (event.cancelable) event.preventDefault();
      ghost.style.left = (gesture.x - ghost.offsetWidth / 2) + 'px';
      ghost.style.top = (gesture.y - ghost.offsetHeight / 2) + 'px';
      updateTarget();
    }
    function end(pointerId, cancelled) {
      if (!gesture || gesture.pointerId !== pointerId) return;
      var current = gesture;
      var destination = target;
      if (current.started && !cancelled) updateTarget();
      destination = target;
      gesture = null;
      if (frame) global.cancelAnimationFrame(frame);
      frame = null;
      if (ghost) ghost.remove();
      ghost = null;
      current.card.classList.remove('is-dragging');
      clearTarget();
      if (current.started) {
        if (current.touch) pendingTouchClick = true;
        suppressUntil = Date.now() + 450;
        suppressCardId = current.id;
        if (!cancelled && destination) options.move(current.id, destination.location, destination.index);
      } else if (current.touch && !cancelled) {
        touchTap(current.id);
      }
    }
    root.addEventListener('click', function (event) {
      var clickedCard = event.target.closest('[data-country]');
      if (Date.now() < suppressUntil && clickedCard &&
          clickedCard.getAttribute('data-country') === suppressCardId) {
        event.preventDefault(); event.stopImmediatePropagation();
      }
    }, true);
    // A touch may synthesize its click after a modal opens or cards move. Suppress
    // that one compatibility click regardless of its newly hit-tested target.
    document.addEventListener('click', function (event) {
      if (pendingTouchClick && event.detail > 0) {
        pendingTouchClick = false;
        event.preventDefault(); event.stopImmediatePropagation();
      }
    }, true);
    document.addEventListener('pointerdown', function () { pendingTouchClick = false; }, true);
    document.addEventListener('touchstart', function () { pendingTouchClick = false; }, { capture: true, passive: true });
    if (global.PointerEvent) {
      root.addEventListener('pointerdown', function (event) {
        if (!event.isPrimary || gesture) return;
        var main = event.target.closest('.card-main');
        if (main && event.pointerType === 'touch' && !options.disabled()) {
          mainTap = {
            id: main.closest('[data-country]').getAttribute('data-country'),
            pointerId: event.pointerId, x: event.clientX, y: event.clientY
          };
        }
        down(event, event, event.pointerId);
      });
      document.addEventListener('pointermove', function (event) {
        if (mainTap && mainTap.pointerId === event.pointerId &&
            Math.abs(event.clientX - mainTap.x) + Math.abs(event.clientY - mainTap.y) > 7) mainTap = null;
        move(event, event, event.pointerId);
      }, { passive: false });
      document.addEventListener('pointerup', function (event) {
        var tap = mainTap;
        mainTap = null;
        end(event.pointerId, false);
        if (tap && tap.pointerId === event.pointerId && !options.disabled()) touchTap(tap.id);
      });
      document.addEventListener('pointercancel', function (event) { mainTap = null; end(event.pointerId, true); });
    } else {
      root.addEventListener('touchstart', function (event) {
        if (gesture || event.touches.length !== 1) return;
        down(event, event.changedTouches[0], 'touch');
      }, { passive: true });
      document.addEventListener('touchmove', function (event) {
        if (gesture && event.touches.length === 1) move(event, event.touches[0], 'touch');
      }, { passive: false });
      document.addEventListener('touchend', function () { end('touch', false); });
      document.addEventListener('touchcancel', function () { end('touch', true); });
      root.addEventListener('mousedown', function (event) { if (!gesture) down(event, event, 'mouse'); });
      document.addEventListener('mousemove', function (event) { move(event, event, 'mouse'); });
      document.addEventListener('mouseup', function () { end('mouse', false); });
    }
    global.addEventListener('blur', function () { mainTap = null; if (gesture) end(gesture.pointerId, true); });
    document.addEventListener('visibilitychange', function () {
      if (document.hidden && gesture) end(gesture.pointerId, true);
    });
    root.addEventListener('dragstart', function (event) { event.preventDefault(); });
  };
})(window);
