(function (global) {
  'use strict';
  var app = global.RA2;
  var locations = app.tiers.map(function (tier) { return tier.id; }).concat(['unranked']);
  function clone(value) { return JSON.parse(JSON.stringify(value)); }
  function ids(version) {
    if (version !== 'ra2' && version !== 'yr') throw new Error('未知游戏版本');
    return app.countries.filter(function (country) {
      return country.versions.indexOf(version) !== -1;
    }).map(function (country) { return country.id; });
  }
  function list(board, location) {
    return location === 'unranked' ? board.unranked : board.tiers[location];
  }
  function createBoard(version) {
    var tiers = {};
    app.tiers.forEach(function (tier) { tiers[tier.id] = []; });
    return {
      title: '国家强度排序',
      tiers: tiers, unranked: ids(version)
    };
  }
  function initial() {
    return { schemaVersion: 1, activeVersion: 'ra2', boards: { ra2: createBoard('ra2'), yr: createBoard('yr') } };
  }
  function validate(board, version) {
    var allowed = ids(version);
    if (!board || typeof board.title !== 'string' || !board.tiers) return false;
    var all = [];
    for (var i = 0; i < locations.length; i++) {
      var current = list(board, locations[i]);
      if (!Array.isArray(current)) return false;
      all = all.concat(current);
    }
    return all.length === allowed.length && allowed.every(function (id) {
      return all.filter(function (value) { return value === id; }).length === 1;
    });
  }
  function locate(board, id) {
    for (var i = 0; i < locations.length; i++) {
      var index = list(board, locations[i]).indexOf(id);
      if (index !== -1) return { location: locations[i], index: index };
    }
    return null;
  }
  // The insertion index refers to the target list AFTER removing the moved card.
  function move(board, version, id, target, index) {
    if (!validate(board, version) || locations.indexOf(target) === -1) throw new Error('排名数据无效');
    var next = clone(board);
    var source = locate(next, id);
    if (!source) throw new Error('当前版本没有此国家');
    list(next, source.location).splice(source.index, 1);
    var destination = list(next, target);
    var position = typeof index === 'number' && isFinite(index) ? Math.floor(index) : destination.length;
    position = Math.max(0, Math.min(destination.length, position));
    destination.splice(position, 0, id);
    if (!validate(next, version)) throw new Error('排名数据校验失败');
    return next;
  }
  function reset(board, version) {
    var next = createBoard(version);
    next.title = board.title;
    return next;
  }
  function limitTitle(title) { return Array.from(title).slice(0, 30).join(''); }
  function normalizeBoard(raw, version) {
    if (!raw || typeof raw !== 'object' || !raw.tiers || typeof raw.tiers !== 'object' ||
        !Array.isArray(raw.unranked) || locations.slice(0, -1).some(function (key) {
          return !Array.isArray(raw.tiers[key]);
        })) throw new Error('存档格式损坏');
    var next = createBoard(version);
    next.title = typeof raw.title === 'string' ? limitTitle(raw.title) : next.title;
    var oldDefault = version === 'ra2' ? '我的红警 2 国家喜好榜' : '我的尤复国家／阵营喜好榜';
    if (raw.title === oldDefault) next.title = '国家强度排序';
    var allowed = ids(version);
    var seen = {};
    locations.forEach(function (location) {
      var clean = list(raw, location).filter(function (id) {
        if (typeof id !== 'string' || allowed.indexOf(id) === -1 || seen[id]) return false;
        seen[id] = true;
        return true;
      });
      if (location === 'unranked') next.unranked = clean;
      else next.tiers[location] = clean;
    });
    allowed.forEach(function (id) { if (!seen[id]) next.unranked.push(id); });
    return next;
  }
  function normalize(raw) {
    if (!raw || raw.schemaVersion !== 1 || !raw.boards || typeof raw.boards !== 'object') {
      throw new Error('不支持此存档版本');
    }
    return {
      schemaVersion: 1, activeVersion: raw.activeVersion === 'yr' ? 'yr' : 'ra2',
      boards: { ra2: normalizeBoard(raw.boards.ra2, 'ra2'), yr: normalizeBoard(raw.boards.yr, 'yr') }
    };
  }
  function createHistory() {
    var stacks = { ra2: [], yr: [] };
    return {
      push: function (version, board) {
        stacks[version].push(clone(board));
        if (stacks[version].length > 20) stacks[version].shift();
      },
      pop: function (version) { return stacks[version].pop() || null; },
      count: function (version) { return stacks[version].length; }
    };
  }
  app.core = {
    clone: clone, ids: ids, list: list, locations: locations, initial: initial,
    createBoard: createBoard, validate: validate, locate: locate, move: move,
    reset: reset, limitTitle: limitTitle, normalize: normalize, createHistory: createHistory
  };
})(window);
