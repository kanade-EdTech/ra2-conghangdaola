(function (global) {
  'use strict';
  var app = global.RA2;
  app.createStorage = function (provider) {
    var key = 'ra2-tier-list:save:v1';
    var protectedSave = false;
    return {
      load: function () {
        try {
          var value = provider().getItem(key);
          if (!value) return { state: app.core.initial(), status: 'new' };
          var parsed = JSON.parse(value);
          var state = app.core.normalize(parsed);
          return { state: state, status: JSON.stringify(parsed) === JSON.stringify(state) ? 'restored' : 'repaired' };
        } catch (error) {
          // Never overwrite a damaged or future-format save automatically.
          protectedSave = true;
          return { state: app.core.initial(), status: 'protected' };
        }
      },
      save: function (state) {
        if (protectedSave) return 'protected';
        try {
          provider().setItem(key, JSON.stringify(state));
          return 'saved';
        } catch (error) { return 'failed'; }
      }
    };
  };
})(window);
