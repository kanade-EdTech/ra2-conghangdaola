(function (global) {
  'use strict';
  var app = global.RA2;
  var font = '"Microsoft YaHei", "PingFang SC", sans-serif';
  function loadImage(path) {
    return new Promise(function (resolve) {
      var image = new Image();
      var done = false;
      var timer = setTimeout(function () { finish(null); }, 4000);
      function finish(value) {
        if (done) return;
        done = true; clearTimeout(timer);
        image.onload = null; image.onerror = null;
        resolve(value);
      }
      image.onload = function () { finish(image); };
      image.onerror = function () { finish(null); };
      image.src = path;
    });
  }
  function wrap(ctx, text, width) {
    var lines = []; var line = '';
    Array.from(text).forEach(function (character) {
      if (line && ctx.measureText(line + character).width > width) { lines.push(line); line = ''; }
      line += character;
    });
    if (line) lines.push(line);
    return lines.length ? lines : ['我的排名'];
  }
  app.createPoster = async function (board, version, width) {
    width = width || 1080;
    var countryIds = app.core.ids(version);
    var loaded = await Promise.all(countryIds.map(function (id) { return loadImage(app.countryById[id].iconPath); }));
    var images = {};
    countryIds.forEach(function (id, index) { images[id] = loaded[index]; });
    var canvas = document.createElement('canvas');
    canvas.width = width;
    var ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('当前环境无法绘制图片，请使用系统截图');
    var scale = width / 1080;
    ctx.font = 'bold ' + (46 * scale) + 'px ' + font;
    var titleLines = wrap(ctx, board.title || '我的排名', 910 * scale);
    var header = 160 + titleLines.length * 58;
    var sections = app.tiers.map(function (tier) {
      return { name: tier.name, color: tier.color, ids: board.tiers[tier.id] };
    });
    if (board.unranked.length) sections.push({ name: '待排名', color: '#a2a9aa', ids: board.unranked });
    var height = header + 122;
    sections.forEach(function (section) {
      section.height = Math.max(118, Math.ceil(section.ids.length / 5) * 126 + 22);
      height += section.height;
    });
    canvas.height = Math.ceil(height * scale);
    if (canvas.width * canvas.height > 4000000) throw new Error('图片尺寸较大，请使用轻量画质');
    ctx = canvas.getContext('2d');
    ctx.scale(scale, scale);
    ctx.fillStyle = '#131719'; ctx.fillRect(0, 0, 1080, height);
    ctx.fillStyle = '#ee6258'; ctx.fillRect(0, 0, 1080, 8);
    ctx.fillStyle = '#a2a9aa'; ctx.font = '19px ' + font;
    ctx.fillText('红色警戒 2  /  从夯到拉', 48, 58);
    ctx.fillStyle = '#f1eee8'; ctx.font = 'bold 46px ' + font;
    titleLines.forEach(function (line, index) { ctx.fillText(line, 48, 125 + index * 58); });
    ctx.fillStyle = '#a2a9aa'; ctx.font = '22px ' + font;
    var placed = countryIds.length - board.unranked.length;
    ctx.fillText(app.versions[version] + '  ·  已排 ' + placed + '/' + countryIds.length, 48, header - 35);
    var y = header;
    sections.forEach(function (section) {
      ctx.fillStyle = '#1c2225'; ctx.fillRect(48, y, 984, section.height - 4);
      ctx.fillStyle = section.color; ctx.fillRect(48, y, 130, section.height - 4);
      ctx.fillStyle = '#202529'; ctx.font = 'bold ' + (section.name.length > 2 ? 28 : 36) + 'px ' + font;
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText(section.name, 113, y + (section.height - 4) / 2);
      section.ids.forEach(function (id, index) {
        var country = app.countryById[id];
        var x = 194 + (index % 5) * 165;
        var cy = y + 12 + Math.floor(index / 5) * 126;
        ctx.fillStyle = '#2a3338'; ctx.fillRect(x, cy, 153, 110);
        ctx.imageSmoothingEnabled = false;
        if (images[id]) ctx.drawImage(images[id], x + 27, cy + 12, 99, 48);
        else {
          ctx.fillStyle = '#c5c9cc'; ctx.font = 'bold 25px ' + font;
          ctx.fillText(country.name.charAt(0), x + 76, cy + 36);
        }
        ctx.fillStyle = '#f1eee8'; ctx.font = '24px ' + font;
        ctx.fillText(country.name, x + 76, cy + 84);
      });
      if (!section.ids.length) {
        ctx.textAlign = 'left'; ctx.fillStyle = '#859094'; ctx.font = '23px ' + font;
        ctx.fillText('这一档暂时空着', 210, y + section.height / 2);
      }
      y += section.height;
    });
    ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic'; ctx.font = '19px ' + font;
    ctx.fillStyle = '#a2a9aa'; ctx.fillText('个人游戏体验 · 仅供交流', 48, y + 55);
    ctx.textAlign = 'right'; ctx.fillText('我的排名，我来定档。', 1032, y + 55);
    var data = canvas.toDataURL('image/png');
    if (!data || data === 'data:,') throw new Error('图片生成失败，请使用轻量画质重试');
    var dimensions = { width: canvas.width, height: canvas.height };
    canvas.width = 1; canvas.height = 1;
    return { data: data, width: dimensions.width, height: dimensions.height };
  };
})(window);
