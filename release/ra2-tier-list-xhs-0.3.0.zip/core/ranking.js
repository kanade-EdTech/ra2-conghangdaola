(function (global) {
  'use strict';
  var app = global.RA2, catalog = app.catalog;
  var locations = app.tiers.map(function (tier) { return tier.id; }).concat(['unranked']);
  function clone(value) { return JSON.parse(JSON.stringify(value)); }
  function ids(context) { return catalog.ids(context); }
  function list(board, location) { return location === 'unranked' ? board.unranked : board.tiers[location]; }
  function createBoard(raw) {
    var context = catalog.context(raw), tiers = {};
    app.tiers.forEach(function (tier) { tiers[tier.id] = []; });
    return { context: context, title: catalog.title(context), tiers: tiers, unranked: ids(context) };
  }
  function initial() {
    return { schemaVersion: 2, catalogRevision: catalog.revision, lastGameVersion: 'ra2', activeBoardKey: 'ra2|countries',
      lastRegularContexts: { ra2: catalog.context({mode:'units',version:'ra2'}), yr: catalog.context({mode:'units',version:'yr'}) },
      boards: { 'ra2|countries': createBoard('ra2'), 'yr|countries': createBoard('yr') } };
  }
  function validate(board, context) {
    var allowed = ids(context);
    if (!board || typeof board.title !== 'string' || !board.tiers) return false;
    var all = [];
    for (var i = 0; i < locations.length; i++) {
      var current = list(board, locations[i]);
      if (!Array.isArray(current)) return false;
      all = all.concat(current);
    }
    return all.length === allowed.length && allowed.every(function (id) { return all.filter(function (value) { return value === id; }).length === 1; });
  }
  function locate(board, id) {
    for (var i = 0; i < locations.length; i++) {
      var index = list(board, locations[i]).indexOf(id);
      if (index !== -1) return { location: locations[i], index: index };
    }
    return null;
  }
  function move(board, context, id, target, index) {
    if (!validate(board, context) || locations.indexOf(target) === -1) throw new Error('排名数据无效');
    var next = clone(board), source = locate(next, id);
    if (!source) throw new Error('当前榜单没有此项目');
    list(next, source.location).splice(source.index, 1);
    var destination = list(next, target);
    var position = typeof index === 'number' && isFinite(index) ? Math.floor(index) : destination.length;
    destination.splice(Math.max(0, Math.min(destination.length, position)), 0, id);
    if (!validate(next, context)) throw new Error('排名数据校验失败');
    return next;
  }
  function reset(board, context) { var next = createBoard(context); next.title = board.title; return next; }
  function limitTitle(title) { return Array.from(title).slice(0, 30).join(''); }
  function normalizeBoard(raw, context) {
    if (!raw || typeof raw !== 'object' || !raw.tiers || !Array.isArray(raw.unranked) || locations.slice(0,-1).some(function (k) { return !Array.isArray(raw.tiers[k]); })) throw new Error('存档格式损坏');
    var next = createBoard(context), allowed = ids(context), seen = Object.create(null);
    next.title = typeof raw.title === 'string' ? limitTitle(raw.title) : next.title;
    if (next.context.mode === 'countries' && raw.title === (next.context.version === 'ra2' ? '我的红警 2 国家喜好榜' : '我的尤复国家／阵营喜好榜')) next.title = '国家强度排序';
    locations.forEach(function (location) {
      var clean = list(raw, location).filter(function (id) {
        if (typeof id !== 'string' || allowed.indexOf(id) === -1 || seen[id]) return false;
        seen[id] = true; return true;
      });
      if (location === 'unranked') next.unranked = clean; else next.tiers[location] = clean;
    });
    allowed.forEach(function (id) { if (!seen[id]) next.unranked.push(id); });
    return next;
  }
  function normalize(raw) {
    if (!raw || !raw.boards || typeof raw.boards !== 'object' || Array.isArray(raw.boards)) throw new Error('存档格式损坏');
    var next = initial();
    if (raw.schemaVersion === 1) {
      next.boards['ra2|countries'] = normalizeBoard(raw.boards.ra2, 'ra2');
      next.boards['yr|countries'] = normalizeBoard(raw.boards.yr, 'yr');
      next.lastGameVersion = raw.activeVersion === 'yr' ? 'yr' : 'ra2';
      next.activeBoardKey = next.lastGameVersion + '|countries';
      return next;
    }
    if (raw.schemaVersion !== 2 || raw.catalogRevision !== catalog.revision) throw new Error('存档或名录版本不支持');
    var keys = Object.keys(raw.boards);
    if (keys.length > 500) throw new Error('存档过大');
    next.boards = Object.create(null);
    keys.forEach(function (key) {
      var board = raw.boards[key], context = catalog.context(board && board.context);
      if (catalog.key(context) !== key) throw new Error('榜单身份无效');
      next.boards[key] = normalizeBoard(board, context);
    });
    if (!Object.prototype.hasOwnProperty.call(next.boards, raw.activeBoardKey)) throw new Error('当前榜单不存在');
    next.activeBoardKey = raw.activeBoardKey;
    next.lastGameVersion = raw.lastGameVersion === 'yr' ? 'yr' : 'ra2';
    if (next.boards[next.activeBoardKey].context.version) next.lastGameVersion = next.boards[next.activeBoardKey].context.version;
    ['ra2','yr'].forEach(function (v) {
      var saved = raw.lastRegularContexts && raw.lastRegularContexts[v];
      if (saved) {
        var c = catalog.context(saved);
        if (c.mode !== 'units' || c.version !== v) throw new Error('常规筛选记录无效');
        next.lastRegularContexts[v] = c;
      }
    });
    return next;
  }
  function createHistory() {
    var stacks = Object.create(null);
    return { push: function (key, board) { var stack = stacks[key] || (stacks[key] = []); stack.push(clone(board)); if (stack.length > 20) stack.shift(); },
      pop: function (key) { return stacks[key] && stacks[key].pop() || null; }, count: function (key) { return stacks[key] ? stacks[key].length : 0; } };
  }
  app.core = { clone: clone, ids: ids, list: list, locations: locations, initial: initial, createBoard: createBoard,
    validate: validate, locate: locate, move: move, reset: reset, limitTitle: limitTitle, normalize: normalize, createHistory: createHistory };
})(window);
