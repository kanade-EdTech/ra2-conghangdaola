(function (global) {
  'use strict';
  var app = global.RA2;
  app.createStorage = function (provider) {
    var key = 'ra2-tier-list:save:v2', protectedSave = false;
    return {
      load: function () {
        try {
          var value = provider().getItem(key), legacy = false;
          if (value === null) { value = provider().getItem('ra2-tier-list:save:v1'); legacy = value !== null; }
          if (value === null) return { state: app.core.initial(), status: 'new' };
          if (value.length > 2000000) throw new Error('Save too large');
          var parsed = JSON.parse(value);
          if (!legacy && parsed.schemaVersion !== 2) throw new Error('Invalid v2 save');
          if (legacy && parsed.schemaVersion !== 1) throw new Error('Invalid legacy save');
          var state = app.core.normalize(parsed);
          return { state: state, status: legacy ? 'migrated' : JSON.stringify(parsed) === JSON.stringify(state) ? 'restored' : 'repaired' };
        } catch (error) {
          protectedSave = true;
          return { state: app.core.initial(), status: 'protected' };
        }
      },
      save: function (state) {
        if (protectedSave) return 'protected';
        try {
          var clean = app.core.clone(state);
          Object.keys(clean.boards).forEach(function (id) {
            if (id !== clean.activeBoardKey && JSON.stringify(clean.boards[id]) === JSON.stringify(app.core.createBoard(clean.boards[id].context))) delete clean.boards[id];
          });
          provider().setItem(key, JSON.stringify(clean));
          return 'saved';
        } catch (error) { return 'failed'; }
      }
    };
  };
})(window);
