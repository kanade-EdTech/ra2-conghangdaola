(function (global) {
  'use strict';
  var app = global.RA2, items = Object.create(null);
  app.categories = { all: '全部类别', infantry: '步兵', ground: '地面载具', naval: '海军', air: '空中单位' };
  app.stages = { all: '全部科技', basic: '基础', radar: '雷达后', lab: '作战实验室后' };
  app.modes = { countries: '国家榜', units: '单位榜', signatures: '国家特色榜', t4: 'T4 科技', others: '其他单位' };
  app.countries.forEach(function (item) { item.kind = 'country'; items[item.id] = item; });
  app.units.concat(app.signatures).forEach(function (item) { items[item.id] = item; });
  function own(object, key) { return Object.prototype.hasOwnProperty.call(object, key); }
  function context(raw) {
    if (typeof raw === 'string') raw = { mode: 'countries', version: raw };
    if (!raw || !own(app.modes, raw.mode)) throw new Error('未知榜单类型');
    if (raw.mode === 'signatures') return { mode: 'signatures', scope: 'shared' };
    if (raw.version !== 'ra2' && raw.version !== 'yr') throw new Error('未知游戏版本');
    var result = { mode: raw.mode, version: raw.version };
    if (raw.mode === 'units') {
      var faction = raw.faction || 'all', category = raw.category || 'all', stage = raw.stage || 'all';
      if ((faction !== 'all' && !own(app.factions, faction)) || !own(app.categories, category) || !own(app.stages, stage)) throw new Error('筛选条件无效');
      if (raw.version === 'ra2' && faction === 'yuri') faction = 'all';
      result.faction = faction; result.category = category; result.stage = stage;
    }
    return result;
  }
  function key(raw) {
    var c = context(raw);
    if (c.mode === 'signatures') return 'shared|signatures';
    if (c.mode !== 'units') return c.version + '|' + c.mode;
    return [c.version, c.mode, c.faction, c.category, 'stage:' + c.stage].join('|');
  }
  function ids(raw) {
    var c = context(raw);
    if (c.mode === 'countries') return app.countries.filter(function (i) { return i.versions.indexOf(c.version) !== -1; }).map(function (i) { return i.id; });
    if (c.mode === 'signatures') return app.signatures.map(function (i) { return i.id; });
    return app.units.filter(function (i) {
      var pool = c.mode === 't4' ? 't4' : c.mode === 'others' ? 'others' : 'regular';
      if (i.version !== c.version || i.rankingPool !== pool) return false;
      return c.mode !== 'units' || ((c.faction === 'all' || i.factions.indexOf(c.faction) !== -1) &&
        (c.category === 'all' || i.categories.indexOf(c.category) !== -1) && (c.stage === 'all' || i.techStage === c.stage));
    }).map(function (i) { return i.id; });
  }
  function summary(raw) {
    var c = context(raw);
    if (c.mode === 'signatures') return '红警 2／尤里的复仇 · 共用特色榜 · 9 种国家特色';
    var text = app.versions[c.version] + ' · ';
    if (c.mode === 'countries') return text + '国家榜';
    if (c.mode === 't4') return text + 'T4 间谍科技 · 独立榜';
    if (c.mode === 'others') return text + '其他单位 · 独立榜';
    return text + (c.faction === 'all' ? '全部阵营' : app.factions[c.faction]) + ' / ' + app.categories[c.category] + ' / ' + app.stages[c.stage];
  }
  function title(raw) {
    var c = context(raw);
    if (c.mode === 'countries') return '国家强度排序';
    if (c.mode === 'signatures') return '国家特色强度排序';
    if (c.mode === 't4') return 'T4 间谍科技强度排序';
    if (c.mode === 'others') return '其他单位强度排序';
    return (c.faction === 'all' ? '' : app.factions[c.faction]) + (c.stage === 'all' ? '' : app.stages[c.stage]) +
      (c.category === 'all' ? '单位' : app.categories[c.category]) + '强度排序';
  }
  function detail(item) {
    if (item.kind === 'country') return app.factions[item.faction] + ' · ' + item.signature;
    if (item.kind === 'signature') return item.countryName + ' · 国家特色';
    if (item.rankingPool === 't4') return '间谍科技 · T4';
    if (item.rankingPool === 'others') return item.note || '战役／特殊单位';
    return item.factions.map(function (f) { return app.factions[f]; }).join('／') + ' · ' + app.stages[item.techStage];
  }
  app.catalog = { revision: 1, context: context, key: key, ids: ids, title: title, summary: summary,
    getItem: function (id) { return items[id] || null; }, detail: detail };
})(window);
